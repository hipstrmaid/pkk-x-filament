<?php $__env->startSection('content'); ?>
    <section class="text-gray-900">
        <div class="w-full">
            <img class="w-full object-cover" src="<?php echo e(Storage::url($berita->thumbnail_berita)); ?>" alt="sejarah">
        </div>
        <div class="content mx-5 px-5 lg:mx-20 lg:px-20 py-10">
            <h1 class="text-2xl md:text-5xl lg:text-4xl text-sky-600 mb-3 font-medium">
                <?php echo e($berita->judul_berita); ?>

            </h1>

            <p class="text-gray-50 text-xs sm:text-sm badge badge-lg badge-info">
                <i class="fas fa-user-circle mr-1"></i> <?php echo e($berita->penulis); ?>

            </p>
            
            <p class="text-gray-50 text-xs sm:text-sm badge badge-lg badge-info">
                <i class="fas fa-calendar mr-2"></i> <?php echo e($berita->tanggal_publish); ?>

            </p>

            <article class="space-y-5 text-justify pt-5 text-gray-600 prose text-sm sm:text-base">
                <?php echo $berita->isi_berita; ?> <!-- Renders the rich text with formatting -->
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/sub-page/view-berita.blade.php ENDPATH**/ ?>