<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <h1 class="text-2xl font-bold text-sky-500 mb-5">BAGAN STRUKTUR TPP. PKK KELURAHAN LAPULU</h1>
        <img src="<?php echo e(Storage::url($struktur->struktur_organisasi)); ?>" alt="struktur-organisasi">
        </h1>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/profile-page/struktur-organisasi.blade.php ENDPATH**/ ?>