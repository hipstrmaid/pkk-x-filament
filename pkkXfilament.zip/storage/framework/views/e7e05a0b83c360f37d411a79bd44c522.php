<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <div class="title-container">
            <h1 class="text-2xl text-sky-500 font-bold mb-5">GALERI</h1>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
            <?php $__currentLoopData = $galeris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Check if 'gambar' is an array or a JSON string
                    $images = is_array($galeri->gambar) ? $galeri->gambar : json_decode($galeri->gambar, true);
                    $firstImage = !empty($images) ? $images[0] : null; // Get the first image or null if empty
                ?>

                <div class="overflow-hidden shadow-lg flex-col">
                    <?php if($firstImage): ?>
                        <img src="<?php echo e(Storage::url($firstImage)); ?>" alt="<?php echo e($galeri->judul_galeri); ?>"
                            class="w-full object-cover h-56">
                    <?php else: ?>
                        <img src="<?php echo e(asset('/assets/gambar/default-image.jpg')); ?>" alt="Default Image"
                            class="w-full object-cover h-56">
                    <?php endif; ?>

                    <div class="p-2 text-center">
                        <a href="" class="text-lg font-semibold"><?php echo e($galeri->judul_galeri); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/informasi-page/galeri.blade.php ENDPATH**/ ?>