<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <div class="title-container">
            <h1 class="text-2xl text-sky-500 font-bold mb-5">INFORMASI TERBARU</h1>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 px-2 py-5">
            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow-md overflow-hidden">
                    <img src="<?php echo e(Storage::url($berita->thumbnail_berita)); ?>" alt="Judul Berita"
                        class="w-full h-48 object-cover">
                    <div class="p-4">
                        <p class="text-gray-500 text-sm"><i class="fas fa-calendar mr-2"></i>
                            <?php echo e(\Carbon\Carbon::parse($berita->tanggal_publish)->translatedFormat('F d, Y')); ?>

                        </p>
                        <a href="<?php echo e(route('berita.show', $berita->slug)); ?>"
                            class="text-lg font-semibold text-info hover:underline"><?php echo e($berita->judul_berita); ?></a>
                        <p class="text-gray-700 mt-2"> <?php echo Str::limit($berita->isi_berita, 80, '...'); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/informasi-page/informasi-terbaru.blade.php ENDPATH**/ ?>