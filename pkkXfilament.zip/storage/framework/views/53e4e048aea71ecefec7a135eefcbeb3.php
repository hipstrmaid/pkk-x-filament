<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <h1 class="text-2xl font-bold text-sky-500">VISI DAN MISI</h1>
        <ul class="text-center flex flex-col gap-3 mt-5">
            <?php echo $visi->visi_misi; ?>

        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/profile-page/visi-misi.blade.php ENDPATH**/ ?>