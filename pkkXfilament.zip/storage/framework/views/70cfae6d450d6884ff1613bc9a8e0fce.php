<footer class="footer bg-sky-800 text-gray-50 p-10 gap-10">
    <aside class="w-full">
        <h6 class="footer-title font-bold text-lg">LOKASI</h6>
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d591.6583038429762!2d122.58180287421195!3d-3.98195624601918!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d98ed29f8eff83d%3A0x692f7867ae5c00fd!2sKantor%20Lurah%20Lapulu!5e0!3m2!1sid!2sid!4v1726985313929!5m2!1sid!2sid"
            style="width: 100%; height: 250px; border: 0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>

    </aside>
    <aside>
        <h6 class="footer-title font-bold text-lg">Kontak</h6>
        <a class="link link-hover">Alamat Kantor : Lapulu, Kec. Abeli, Kota Kendari, Sulawesi Tenggara 93885</a>
        <a class="link link-hover">Telpon : 0800 0000 0000</a>
    </aside>
    <aside>
        <h6 class="footer-title font-bold text-lg">Administrator</h6>
        <a href="/admin" class="link link-hover">Login</a>

    </aside>
</footer>
<footer class="footer footer-center bg-base-300 text-base-content p-4">
    <aside>
        <p>Copyright &copy TP.PKK Kelurahan Lapulu 2024. All rights reserved.</p>
    </aside>
</footer>
<?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/includes/footer.blade.php ENDPATH**/ ?>