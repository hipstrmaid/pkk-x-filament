<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.welcome-page.hero-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="pt-5 px-5 lg:px-10">
        <?php echo $__env->make('frontend.welcome-page.video-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('frontend.welcome-page.pokja-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="px-10">
        <?php echo $__env->make('frontend.welcome-page.profile-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('frontend.welcome-page.berita-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.welcome-page.time-divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="px-10">
        <?php echo $__env->make('frontend.welcome-page.galeri-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script>
        const items = document.querySelectorAll('.carousel-item');
        const circles = document.querySelectorAll('.circle');
        let currentIndex = 0;

        function changeSlide() {
            items[currentIndex].classList.remove('active');
            circles[currentIndex].classList.remove('active');

            currentIndex = (currentIndex + 1) % items.length;

            items[currentIndex].classList.add('active');
            circles[currentIndex].classList.add('active');
        }

        // Change slide every 3 seconds (3000 ms)
        setInterval(changeSlide, 6000);


        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const currentTime = `${hours}:${minutes}:${seconds}`;

            document.getElementById('clock').textContent = currentTime;
        }

        // Update the clock every second
        setInterval(updateClock, 1000);

        // Initialize clock display
        updateClock();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/welcome.blade.php ENDPATH**/ ?>