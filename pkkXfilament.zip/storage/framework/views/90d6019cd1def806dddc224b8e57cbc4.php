<div class="flex w-full flex-col mt-10">
    <div class="divider divider-neutral text-3xl font-bold text-sky-800">BERITA TERBARU</div>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 px-10 py-5">
    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden transition-transform transform hover:scale-105">
            <img src="<?php echo e(Storage::url($berita->thumbnail_berita)); ?>" alt="Judul Berita" class="w-full h-48 object-cover">
            <div class="p-4">
                <a href="<?php echo e(route('berita.show', $berita->slug)); ?>"
                    class="text-md font-bold text-blue-600 hover:underline transition-colors duration-200"><?php echo e($berita->judul_berita); ?></a>
                <p class="text-gray-500 text-xs mt-1">
                    <i class="fas fa-calendar mr-2"></i>
                    <?php echo e(\Carbon\Carbon::parse($berita->tanggal_publish)->translatedFormat('F d, Y')); ?>

                </p>
                <p class="text-gray-700 mt-2 text-sm leading-snug">
                    <?php echo Str::limit($berita->isi_berita, 80, '...'); ?>

                </p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/welcome-page/berita-section.blade.php ENDPATH**/ ?>