<div class="collapse collapse-plus border border-3 border-gray-500 w-full shadow-md">
    <input type="radio" name="my-accordion-3" />
    <div class="collapse-title text-md font-bold text-gray-900 text-lg"><?php echo e($judul); ?></div>
    <div class="collapse-content">
        <p class=" text-gray-900"><?php echo e($slot); ?></p>

    </div>
</div>
<?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/components/accordion.blade.php ENDPATH**/ ?>