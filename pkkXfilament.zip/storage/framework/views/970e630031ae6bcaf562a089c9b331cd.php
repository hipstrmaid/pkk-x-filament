<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <div class="title-container">
            <h1 class="text-2xl text-sky-500 font-bold mb-5">GALERI</h1>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
            <?php if(!empty($images) && is_array($images)): ?>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="overflow-hidden shadow-lg flex-col">
                        <img src="<?php echo e(Storage::url($image)); ?>" alt="Gambar <?php echo e($galeri->judul_galeri); ?>"
                            class="w-full object-cover h-56">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No images available for this gallery.</p>
            <?php endif; ?>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/sub-page/view-galeri.blade.php ENDPATH**/ ?>