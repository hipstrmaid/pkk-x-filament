<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center text-gray-900 p-10">
        <div class="title-container">
            <h1 class="text-2xl text-sky-500 font-bold mb-10">PROFIL PJ.KETUA PKK</h1>
        </div>


        <div class="container grid grid-cols-1 lg:grid-cols-8 flex justify-center gap-2">
            <div class="img col-span-4 justify-center flex items-center">
                <img src="<?php echo e(asset('assets/gambar/person.webp')); ?>" alt="ketua tp. pkk kelurahan lapulu" class="px-5 pt-5">
            </div>
            <div class="wrapper col-span-4">
                <div class="bg-white overflow-hidden shadow rounded-lg border w-full">
                    <div class="px-4 py-5 sm:px-6">
                        <h3 class="text-lg leading-6 font-bold text-gray-900">
                            PROFIL PJ.KETUA PKK
                        </h3>
                        
                    </div>
                    <div class="border-t border-gray-200 px-4 py-5 sm:p-0">
                        <dl class="sm:divide-y sm:divide-gray-200 flex flex-col">
                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt class="text-sm font-medium text-gray-500">
                                    Nama
                                </dt>
                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    <?php echo e($data->nama); ?>

                                </dd>
                            </div>
                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt class="text-sm font-medium text-gray-500">
                                    Tempat, Tanggal Lahir
                                </dt>
                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    <?php echo e($data->tempat_lahir); ?> , <?php echo e($data->tanggal_lahir); ?>

                                </dd>
                            </div>
                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt class="text-sm font-medium text-gray-500">
                                    Agama
                                </dt>
                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    Islam
                                </dd>
                            </div>
                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt class="text-sm font-medium text-gray-500">
                                    Alamat
                                </dt>
                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    <?php echo e($data->alamat); ?>

                                </dd>
                            </div>
                        </dl>
                    </div>
                </div>

            </div>
            

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/profile-page/profil-pj.blade.php ENDPATH**/ ?>