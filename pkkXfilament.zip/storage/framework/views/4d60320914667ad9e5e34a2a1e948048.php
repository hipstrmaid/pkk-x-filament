<div class="relative bg-sky-500 p-5">
    <div class="relative z-10 text-center">
        <i class="fas fa-clock text-white mr-2 text-lg"></i> <!-- Icon Jam -->
        <span class="text-xl text-white font-bold" id="clock">00:00:00</span>
    </div>
</div>
<?php /**PATH D:\PROYEK WEBSITE\pkkXfilament\resources\views/frontend/welcome-page/time-divider.blade.php ENDPATH**/ ?>