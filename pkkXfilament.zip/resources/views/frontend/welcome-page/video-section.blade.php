{{-- <div>
    <div class="flex w-full flex-col">
        <div class="divider divider-neutral text-3xl font-bold text-sky-800">VIDEO</div>
    </div>

    <div class="shadow shadow-lg">
        <iframe src="https://drive.google.com/file/d/1FNt92TXgSIyKtEkYoiM7Pe4-R_QZj8Kn/preview" width="640"
            height="480" allow="autoplay" class="responsive-iframe w-full"></iframe>

    </div>

</div> --}}
