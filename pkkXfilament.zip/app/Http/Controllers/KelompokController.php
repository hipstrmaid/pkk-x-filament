<?php

namespace App\Http\Controllers;

use App\Models\Kelompok;
use Illuminate\Http\Request;

class KelompokController extends Controller
{
    // public function showSekretariat()
    // {
    //     $sekretariat = Kelompok::where('nama_kelompok', 'sekretariat')->firstOrFail();
    //     return view('frontend.pokja-page.sekretariat', compact('sekretariat'));
    // }

}
